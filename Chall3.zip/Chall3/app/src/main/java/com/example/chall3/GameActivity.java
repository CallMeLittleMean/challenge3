package com.example.chall3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class GameActivity extends AppCompatActivity {

    private TextView livesText, timerText, scoreText, questionText;
    private EditText answerInput;
    private Button submitButton, nextButton;
    private int lives = 3;
    private int score = 0;
    private int timeLeft = 60;
    private final Handler handler = new Handler();
    private Runnable timerRunnable;
    private String operation;
    private int num1, num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_mathgame);

        operation = getIntent().getStringExtra("operation");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        switch (operation) {
            case "addition":
                toolbar.setTitle("Addition Game");
                break;
            case "subtraction":
                toolbar.setTitle("Subtraction Game");
                break;
            case "multiplication":
                toolbar.setTitle("Multiplication Game");
                break;
        }

        livesText = findViewById(R.id.livesText);
        timerText = findViewById(R.id.timerText);
        scoreText = findViewById(R.id.scoreText);
        questionText = findViewById(R.id.questionText);
        answerInput = findViewById(R.id.answerInput);
        submitButton = findViewById(R.id.submitButton);
        nextButton = findViewById(R.id.nextButton);

        nextButton.setOnClickListener(v -> {
            generateQuestion();
        });

        startGame();
    }

    private void startGame() {
        lives = 3;
        score = 0;
        timeLeft = 60;
        updateDisplay();
        generateQuestion();
        startTimer();
        submitButton.setOnClickListener(v -> checkAnswer());
    }

    @SuppressLint("SetTextI18n")
    private void generateQuestion() {
        num1 = (int) (Math.random() * 100);
        num2 = (int) (Math.random() * 100);

        if (operation.equals("subtraction") && num1 < num2) {
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }

        if (operation.equals("multiplication")) {
            num1 = (int) (Math.random() * 10) + 1;
            num2 = (int) (Math.random() * 10) + 1;
        }

        switch (operation) {
            case "addition":
                questionText.setText(num1 + " + " + num2 + " = ?");
                break;
            case "subtraction":
                questionText.setText(num1 + " - " + num2 + " = ?");
                break;
            case "multiplication":
                questionText.setText(num1 + " × " + num2 + " = ?");
                break;
        }
        answerInput.setText("");
    }

    private void startTimer() {
        timerRunnable = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                timeLeft--;
                timerText.setText("Time: " + timeLeft + "s");
                if (timeLeft <= 0) {
                    endGame();
                } else {
                    handler.postDelayed(this, 1000);
                }
            }
        };
        handler.postDelayed(timerRunnable, 1000);

        nextButton.setOnClickListener(v -> {
            generateQuestion();
            submitButton.setEnabled(true);
        });
    }

    private void checkAnswer() {
        try {
            int userAnswer = Integer.parseInt(answerInput.getText().toString());
            int correctAnswer = 0;

            switch (operation) {
                case "addition":
                    correctAnswer = num1 + num2;
                    break;
                case "subtraction":
                    correctAnswer = num1 - num2;
                    break;
                case "multiplication":
                    correctAnswer = num1 * num2;
                    break;
            }

            if (userAnswer == correctAnswer) {
                score += 10;
                updateDisplay();
                generateQuestion();
            } else {
                lives--;
                updateDisplay();
                if (lives <= 0) {
                    endGame();
                } else {
                    generateQuestion();
                }
            }
        } catch (NumberFormatException e) {
        }
    }

    @SuppressLint("SetTextI18n")
    private void updateDisplay() {
        livesText.setText("Lives: " + lives);
        scoreText.setText("Score: " + score);
    }

    @SuppressLint("SetTextI18n")
    private void endGame() {
        handler.removeCallbacks(timerRunnable);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_result);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TextView finalScoreText = findViewById(R.id.finalScoreText);
        Button playAgainButton = findViewById(R.id.playAgainButton);
        Button exitButton = findViewById(R.id.exitButton);

        finalScoreText.setText("Score: " + score);

        playAgainButton.setOnClickListener(v -> {
            Intent intent = new Intent(GameActivity.this, GameActivity.class);
            intent.putExtra("operation", operation);
            startActivity(intent);
            finish();
        });

        exitButton.setOnClickListener(v -> finish());
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
